//
//  DSLMCVIDCardDetectObserverDelegate.h
//  DSLMCVIDCard
//
//  Created by chenliqun13 on 2020/11/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DSLMCVIDCardResult.h"
#import "DSLMCVIDCardNextOperation.h"

@protocol DSLMCVIDCardDetectObserverDelegate <NSObject>

@optional

/**
 必须实现这个代理，当前操作动作返回
 
 @param command DSLMCVIDCardNextOperation对象,其中的操作动作对应如下
  DSLMCVIDCardOperation_Default = -1,
  DSLMCVIDCardOperation_BEGIN,     // 开始
  DSLMCVIDCardOperation_ORTH,      // 可以进行步骤一
  DSLMCVIDCardOperation_FLASH,     // 可以进行步骤二
  DSLMCVIDCardOperation_UP,        // 可以进行步骤三
  DSLMCVIDCardOperation_BACK,      // 可以进行步骤四
  DSLMCVIDCardOperation_COMPLETE,  //识别完成
  
  DSLMCVIDCardOperation_VALID,       //当【距离过远，距离过近，转速过快】恢复正常时，会发送VALID消息，UI需要恢复显示当前动作的提示语
  DSLMCVIDCardOperation_INVALID,       //当无法检测到证件正面的时候会提示，目前设置是5s钟提示一次
  DSLMCVIDCardOperation_BLUR,      //视频模糊(注意: 仅仅是提示，与动作流程无关，当转速恢复正常后，需要继续显示当前动作的提示语)
  DSLMCVIDCardOperation_FAR,        //距离过远(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
  DSLMCVIDCardOperation_EXCEED_TOP,      //证件上边超出范围，不在框内
  DSLMCVIDCardOperation_EXCEED_EXCEED_BOTTOM,      //证件下边超出范围，不在框内
  DSLMCVIDCardOperation_EXCEED_EXCEED_RIGHT,      //证件右边超出范围，不在框内
  DSLMCVIDCardOperation_EXCEED_EXCEED_LEFT,      //证件左边超出范围，不在框内
  DSLMCVIDCardOperation_INVALID_CARD,    //检查不到证件，可能出现在拍摄正面闪光灯照片或背面证件时
  DSLMCVIDCardOperation_LESS_ROTATE,    //向上旋转未到角度
  DSLMCVIDCardOperation_MORE_ROTATE,    //向上旋转角度过大
  DSLMCVIDCardOperation_Exposure,      //表示当前返回反光过强
  DSLMCVIDCardOperation_Dark,          //光线过暗
  DSLMCVIDCardOperation_DIRECTION_UP,//证件顶部向上
  DSLMCVIDCardOperation_DIRECTION_BOTTOM,//证件顶部向下
  DSLMCVIDCardOperation_DIRECTION_RIGHT,//证件顶部向右
  DSLMCVIDCardOperation_DIRECTION_LEFT,//证件顶部向左
  DSLMCVIDCardOperation_DIRECTION_TILT//证件倾斜
 
 */
-(void)didUpdateOperationCommand:(DSLMCVIDCardNextOperation *)command;

/**
 必须实现这个代理，识别结果返回

 @param result 识别结果返回,具体请参考DSLMCVIDCardResult.h
 */
-(void)didDetectResult:(DSLMCVIDCardResult *)result;

@end
