//
//  DSLHKIDCardNextOperation.h
//  DSLHKIDCard
//  识别过程中，当前操作动作返回提示
//  Created by chentao on 2018/7/9.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,DSLHKIDCardOperationStatus){
    DSLHKIDCardOperation_Default = -1,
    DSLHKIDCardOperation_BEGIN,     // 开始识别
    DSLHKIDCardOperation_ORTH,      // 2003版表示向上(2018版本表示向右)翻转开始
    DSLHKIDCardOperation_ORTH_HALF,      // 2003版表示向上(2018版本表示向右)已经翻转一半
    DSLHKIDCardOperation_LEFTDOWN,  // 2003版表示向下(2018版本表示向左)翻转开始
    DSLHKIDCardOperation_LEFTDOWN_HALF,  // 2003版表示向下(2018版本表示向左)已经翻转一半
    DSLHKIDCardOperation_RESET,      //复位(请缓慢把证件复位，正面放置在框内)，2018版证件当向右翻动作完成及2003版证件当向上翻动作完成时会收到
    DSLHKIDCardOperation_RESET_HALF,    //已经复位到一半(请缓慢把证件复位，正面放置在框内)，2018版证件当向右翻动作完成及2003版证件当向上翻动作完成时会收到
    DSLHKIDCardOperation_COMPLETE,  //识别完成
    DSLHKIDCardOperation_VALID,       //当【距离过远，距离过近，转速过快】恢复正常时，会发送VALID消息，UI需要恢复显示当前动作的提示语
    DSLHKIDCardOperation_INVALID,       //当无法检测到证件正面的时候会提示，目前设置是5s钟提示一次
    DSLHKIDCardOperation_BLUR,      //视频模糊(注意: 仅仅是提示，与动作流程无关，当转速恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_FAR,        //距离过远(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_NEAR,       //距离过近(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_OUT_OF_RANGE,    //证件超出范围，不在框内
    DSLHKIDCardOperation_NO_PARALLEL_TO_MOBILEPHONE, //证件没有与手机平行放置
    DSLHKIDCardOperation_DIRECTION_UP,//证件顶部向上
    DSLHKIDCardOperation_DIRECTION_BOTTOM,//证件顶部向下
    DSLHKIDCardOperation_DIRECTION_RIGHT,//证件顶部向右
    DSLHKIDCardOperation_DIRECTION_LEFT,//证件顶部向左
    DSLHKIDCardOperation_DIRECTION_TILT,//证件倾斜
    DSLHKIDCardOperation_STOP1,//暂停,保持当前操作姿势不动
    DSLHKIDCardOperation_STOP2,//暂停,保持当前操作姿势不动
    DSLHKIDCardOperation_STOP3,//暂停,保持当前操作姿势不动
    DSLHKIDCardOperation_OCCLUSION//手指遮挡错误
};
 
@interface DSLHKIDCardNextOperation : NSObject

// 当前识别状态
@property(nonatomic,assign)DSLHKIDCardOperationStatus currentStatus;

// 为nil,可以不关注; 提示语为了方便管理和支持多语言统一放到Localizable.strings文件，在外部配置
@property(nonatomic,copy)NSString *nextOperationHint;

@end
