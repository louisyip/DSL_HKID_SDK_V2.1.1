//
//  DSLHKIDCardResult.h
//  DSLHKIDCardDemo
//
//  Created by chentao on 2018/7/5.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

//身份证件类型版本
typedef NS_ENUM(NSInteger,DSLHKIDCardType){
    DSLHKIDCardType_Default = -1,
    DSLHKIDCardType_2018,       //身份证件2018版本
    DSLHKIDCardType_2003        //身份证件2003版本
};

//识别结果
typedef NS_ENUM(NSInteger,DSLHKIDCardResultStatus){
    DSLHKIDCardResultStatus_Default = -1,
    DSLHKIDCardResultStatus_Success,          //  识别成功
    DSLHKIDCardResultStatus_FirstActionOver,  //当前返回第一个动作的静态证件图片
    DSLHKIDCardResultStatus_Exposure,         //表示当前返回反光过强，重新开始识别
    DSLHKIDCardResultStatus_Lost,             //目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
    DSLHKIDCardResultStatus_Overtime,         //识别超时,超时时间可以设置
    DSLHKIDCardResultStatus_Dark,             //光线过暗，重新开始识别
    DSLHKIDCardResultStatus_Invalid           //不正确的操作动作，重新开始识别
    
};

@interface DSLHKIDCardResult : NSObject

//证件类型
@property(nonatomic, assign) DSLHKIDCardType idCardType;
//识别结果
@property(nonatomic, assign) DSLHKIDCardResultStatus idCardResultStatus;

// 图片数据
//1.当success为NO,retCode为1时，则数组的第一张图片为静态证件图片，其他情况为空
//2.当success为YES,retCode为0时,则数组的第一张图片为静态证件图片，最后一张为人脸比对的证件头像图片
@property(nonatomic,copy)NSArray<NSData *> *imageDataArray;
@property(nonatomic, strong) NSArray* idxArray;
@end
