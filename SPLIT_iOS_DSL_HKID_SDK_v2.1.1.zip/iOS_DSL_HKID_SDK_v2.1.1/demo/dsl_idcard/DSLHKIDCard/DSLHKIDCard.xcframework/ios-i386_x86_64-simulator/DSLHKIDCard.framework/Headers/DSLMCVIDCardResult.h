//
//  DSLMCVIDCardResult.h

//
//  Created by chenliqun13 on 2020/11/26.
//  Copyright © 2020 chenliqun. All rights reserved.
//

#import <Foundation/Foundation.h>

//识别结果
typedef NS_ENUM(NSInteger,DSLMCVIDCardResultStatus){
    DSLMCVIDCardResultStatus_Default = -1,
    DSLMCVIDCardResultStatus_Success,          //  识别成功
    DSLMCVIDCardResultStatus_Lost,             //目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
    DSLMCVIDCardResultStatus_Overtime,         //识别超时,超时时间可以设置
    DSLMCVIDCardResultStatus_Pause_Photo        //识别过程中,吐出图片供页面显示
};

@interface DSLMCVIDCardResult : NSObject

//识别结果
@property(nonatomic, assign) DSLMCVIDCardResultStatus idCardResultStatus;

// 图片数据
//2.当idCardResultStatus为DSLMCVIDCardResultStatus_Success,则数组会返回7张图片，其中0到3共4张是需要传给后台;4和5分别是矫正后的正面图像和矫正后的侧面图像，6矫正后的背面，4到6是用于与结果显示
@property(nonatomic,copy)NSArray<NSData *> *imageDataArray;

@end
