package com.zhongan.liveness.log.model;

public class CustomModel {

    private String actionName;//动作名称
    private String actionStartTimeStamp;//动作开始时间戳，单位：毫秒
    private String actionEndTimeStamp;//动作结束时间戳，单位毫秒
    private boolean isActionOK;//动作是否成功

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getActionStartTimeStamp() {
        return actionStartTimeStamp;
    }

    public void setActionStartTimeStamp(String actionStartTimeStamp) {
        this.actionStartTimeStamp = actionStartTimeStamp;
    }

    public String getActionEndTimeStamp() {
        return actionEndTimeStamp;
    }

    public void setActionEndTimeStamp(String actionEndTimeStamp) {
        this.actionEndTimeStamp = actionEndTimeStamp;
    }

    public boolean isActionOK() {
        return isActionOK;
    }

    public void setActionOK(boolean actionOK) {
        isActionOK = actionOK;
    }
}
