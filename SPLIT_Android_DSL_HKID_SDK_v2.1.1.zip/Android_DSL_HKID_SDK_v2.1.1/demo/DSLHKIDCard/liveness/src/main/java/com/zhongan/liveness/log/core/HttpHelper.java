package com.zhongan.liveness.log.core;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.liveness.ZaOcrApplications;
import com.zhongan.liveness.log.ZALog;
import com.zhongan.liveness.util.NetWorkUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPOutputStream;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;
import okio.GzipSink;
import okio.Okio;

public class HttpHelper {

    HttpCallback callback;

    static class GzipRequestInterceptor implements Interceptor {
        @Override public Response intercept(Chain chain) throws IOException {
            Request originalRequest = chain.request();
            if (originalRequest.body() == null || originalRequest.header("Content-Encoding") != null) {
                return chain.proceed(originalRequest);
            }

            Request compressedRequest = originalRequest.newBuilder()
                    .header("Content-Encoding", "gzip")
                    .method(originalRequest.method(), gzip(originalRequest.body()))
                    .build();
            return chain.proceed(compressedRequest);
        }

        private RequestBody gzip(final RequestBody body) {
            return new RequestBody() {
                @Override public MediaType contentType() {
                    return body.contentType();
                }

                @Override public long contentLength() {
                    return -1; // 无法知道压缩后的数据大小
                }

                @Override public void writeTo(BufferedSink sink) throws IOException {
                    BufferedSink gzipSink = Okio.buffer(new GzipSink(sink));
                    body.writeTo(gzipSink);
                    gzipSink.close();
                }
            };
        }
    }


    public static final MediaType MEDIA_TYPE_JSON
            = MediaType.parse("application/json; charset=utf-8");
    /**
     * 采用单例模式使用OkHttpClient
     */
    private static HttpHelper mOkHttpHelperInstance;
    private static OkHttpClient mClientInstance;
    private Handler mHandler;

    private static String requestUrl;

    /**
     * 单例模式，私有构造函数，构造函数里面进行一些初始化
     */
    private HttpHelper() {
        mClientInstance = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)       //设置连接超时
                .readTimeout(120, TimeUnit.SECONDS)          //设置读超时
                .writeTimeout(120, TimeUnit.SECONDS)          //设置写超时
                .retryOnConnectionFailure(true)             //是否自动重连
                .addInterceptor(new GzipRequestInterceptor())
                .build();
        mHandler = new Handler(Looper.getMainLooper());
    }

    /**
     * 获取实例
     *
     * @return
     */
    public static HttpHelper getInstance() {
        if (mOkHttpHelperInstance == null) {

            synchronized (HttpHelper.class) {
                if (mOkHttpHelperInstance == null) {
                    mOkHttpHelperInstance = new HttpHelper();
                }
            }
        }
        return mOkHttpHelperInstance;
    }

    /**
     * 封装一个request方法，不管post或者get方法中都会用到
     */
    public void request(final Request request, final HttpCallback mCallback) {
        callback=mCallback;
        requestUrl = request.url().url().toString();
        ZALog.e("请求URL",requestUrl);
        if (!NetWorkUtil.isNetworkAvailable(ZaOcrApplications.context())) {
            return;
        }
        //在请求之前所做的事，比如弹出对话框等
        callback.onRequestBefore();

//        try {
//            Log.e("++++++++++上传数据==",request.body().contentLength()+"");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        mClientInstance.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                ZALog.e("response for:", requestUrl + " :" + e.getMessage());
                callbackFailure( callback, e.getMessage(), ResponseCode.msgError);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String resString="";
                try {
                    resString = response.body().string();
                    ZALog.e("response for:", requestUrl + " :" + resString+"response.isSuccessful()=="+response.isSuccessful()+"responseCode=="+response.code());
                if(TextUtils.isEmpty(resString)){
                    return;
                }
                if (response.isSuccessful()) {
                    //返回成功回调
                    try {
                        JSONObject jsonObj = JSON.parseObject(resString);
                        String returnCode = jsonObj.getString("statusCode");
                        String returnMsg="";
                        try {
                            returnMsg = jsonObj.getString("message");
                        }catch (JSONException e1){
                        }
                        if (Integer.valueOf(returnCode) == 0) {
                            callbackSuccess(response, jsonObj, callback);
                        } else {
                            callbackFailure(callback, returnMsg, Integer.valueOf(returnCode));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callbackError(callback,e,ResponseCode.dataError,"");
                    }catch (Exception e){
                        ZALog.e("HttpHelper_isSuccessful",e.getMessage()+"");
                        callbackError(callback,e,ResponseCode.dataError,"");
                    }
                } else {
                    //返回错误
                    JSONObject jsonObj = null;
                    try {
                        jsonObj = JSON.parseObject(resString);
                        int returnCode = Integer.valueOf(jsonObj.getString("resultCode"));
                        callbackFailure(callback, response.message(), returnCode);
                    } catch (JSONException e) {
                        e.printStackTrace();
                        callbackError(callback,e,ResponseCode.dataError,"");
                    }catch (Exception e1){
                        ZALog.e("HttpHelper",e1.getMessage()+"");
                        callbackError(callback,e1,ResponseCode.dataError,"");
                    }
                }
                }catch (Exception e){
                    callbackError(callback,e,ResponseCode.dataError,"");
                }
            }

        });
    }

    /**
     * 在主线程中执行的回调
     *
     * @param response
     * @param
     * @param callback
     */
    private void callbackSuccess(final Response response, final JSONObject o, final HttpCallback callback) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onSuccess(response, o);
            }
        });
    }

    /**
     * 请求出错调用
     *
     * @param callback
     * @param e
     */
    private void callbackError(final HttpCallback callback, final Exception e, final int code, final String errorMsg) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onError(ResponseCode.msgError, e);
            }
        });
    }

    /**
     * 业务失败调用
     *
     * @param callback
     * @param errorMsg
     * @param code
     */
    private void callbackFailure(final HttpCallback callback, final String errorMsg, final int code) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                callback.onFailure(errorMsg, code);
            }
        });
    }

    /**
     * 对外公开的get方法
     *
     * @param url
     * @param callback
     */
    public void get(String url, Map<String, String> params, HttpCallback callback) {
        StringBuilder tempParams = new StringBuilder();
        String requestUrl;
        if (params != null) {
            try {
                int i=0;
                for (String key : params.keySet()) {
                    if(i==0){
                        tempParams.append(String.format("?%s=%s", key, URLEncoder.encode(params.get(key), "utf-8")));
                    }else {
                        tempParams.append(String.format("&%s=%s", key, URLEncoder.encode(params.get(key), "utf-8")));
                    }
                    i++;
                }
                //对参数进行URLEncoder


            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            //补全请求地址
            requestUrl = String.format("%s%s", url, tempParams.toString());
        } else {
            requestUrl = url;
        }
        //创建一个请求
        Request request = buildRequest(requestUrl, null, HttpMethodType.GET);
        request(request, callback);
    }

    /**
     * 对外公开的post方法
     *
     * @param url
     * @param params
     * @param callback
     */
    public void post(String url, JSONObject params, HttpCallback callback) {
        Log.v("++++++++++上传数据==", "构造Request");
        Request request = buildRequest(url, params, HttpMethodType.POST);
        request(request, callback);
        Log.v("++++++++++上传数据==", "构造Request完成");
    }

    /**
     * 对外公开的post方法
     *
     * @param url
     * @param params
     * @param callback
     */
    public void postArray(String url, JSONObject params, HttpCallback callback) {
        Log.v("++++++++++上传数据==", "构造Request");
        Request request = buildArrayRequest(url, params, HttpMethodType.POST);
        request(request, callback);
        Log.v("++++++++++上传数据==", "构造Request完成");
    }

    /**
     * 对外公开delete方法
     *
     * @param url
     * @param params
     * @param callback
     */
    public void delete(String url, JSONObject params, HttpCallback callback) {
        Request request = buildRequest(url, params, HttpMethodType.DELETE);
        request(request, callback);
    }


    /**
     * 对外公开上传资源方法无附加参数
     *
     * @param url
     * @param filePath
     * @param callback
     */
    public void uploadFile(String url, String filePath, HttpCallback callback) {
        File file = new File(filePath);
        RequestBody body = RequestBody.create(MediaType.parse("text/plain"), file);
        final Request request = new Request.Builder().url(url).post(body).build();
        request(request, callback);
    }

    /**
     * 对外公开上传资源方法 有附加参数
     * @param actionUrl
     * @param paramsMap
     * @param callBack
     */
    public void uploadFile(String actionUrl, Map<String, Object> paramsMap, final HttpCallback callBack) {
        MultipartBody.Builder builder = new MultipartBody.Builder();
        //设置类型
        builder.setType(MultipartBody.FORM);
        //追加参数
        for (String key : paramsMap.keySet()) {
            Object object = paramsMap.get(key);
            if (!(object instanceof File)) {
                builder.addFormDataPart(key, object.toString());
            } else {
                File file = (File) object;
                builder.addFormDataPart(key, file.getName(), RequestBody.create(null, file));
            }
        }
        //创建RequestBody
        RequestBody body = builder.build();
        //创建Request
        final Request request = new Request.Builder().url(actionUrl).post(body).build();
        request(request, callBack);

    }


    /**
     * 构建请求对象
     *
     * @param url
     * @param params
     * @param type
     * @return
     */
    private Request buildArrayRequest(String url, JSONObject params, HttpMethodType type) {
        Request.Builder builder = new Request.Builder();
        builder.url(url);
        builder.addHeader("Content-Encoding", "gzip");
//        builder.addHeader("Accept-Encoding", "gzip");
        if (type == HttpMethodType.GET) {
            builder.get();
        } else if (type == HttpMethodType.POST) {
            try {
                ZALog.e("ungzip",params.toString().length()+"");
                builder.post(getGzipRequest(params.toString()));
            }catch (OutOfMemoryError e){
                callbackFailure(callback, e.getMessage(), ResponseCode.msg_50);
            }
        } else if (type == HttpMethodType.DELETE) {
            builder.delete(buildRequestBody(params.toString()));
        }
        return builder.build();
    }


    /**
     * 构建请求对象
     *
     * @param url
     * @param params
     * @param type
     * @return
     */
    private Request buildRequest(String url, JSONObject params, HttpMethodType type) {
        Request.Builder builder = new Request.Builder();
        builder.url(url);
        builder.addHeader("Content-Encoding", "gzip");
//        builder.addHeader("Accept-Encoding", "gzip");
        if (type == HttpMethodType.GET) {
            builder.get();
        } else if (type == HttpMethodType.POST) {
            try {
                builder.post(getGzipRequest(params.toString()));
            }catch (OutOfMemoryError e){
                callbackFailure(callback, e.getMessage(), ResponseCode.msg_50);
            }
        } else if (type == HttpMethodType.DELETE) {
            builder.delete(buildRequestBody(params.toString()));
        }
        return builder.build();
    }

    public RequestBody getGzipRequest(String body) {
        RequestBody request = null;
        try {
            request = RequestBody.create(MEDIA_TYPE_JSON, compress(body));
            ZALog.e("gzip",request.contentLength()+"");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return request;

    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static byte[] compress(String str) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            try (GZIPOutputStream gzip = new GZIPOutputStream(out)) {
                gzip.write(str.getBytes(StandardCharsets.UTF_8));
            }
            return out.toByteArray();
        }
    }


    /**
     * 通过Map的键值对构建请求对象的body
     *
     * @param params
     * @return
     */
    private RequestBody buildRequestBody(String params) {
        return RequestBody.create(MEDIA_TYPE_JSON, params);
    }

    /**
     * 这个枚举用于指明是哪一种提交方式
     */
    enum HttpMethodType {
        GET,
        POST,
        PUT,
        DELETE
    }


    public static String getRequestUrl() {
        return requestUrl;
    }
}
