package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

import android.view.Surface;

public interface OnSurfaceCreatedCallback {
    void onSurfaceCreate(Surface surface);
}
