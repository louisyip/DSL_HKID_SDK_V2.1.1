package com.dsl.ocrdemo.ocr.views.camera1;


import android.app.Activity;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.dsl.ocr.manager.OcrNative;
import com.dsl.ocr.util.DSLLog;
import com.dsl.ocrdemo.ocr.manager.OcrSDKManager;
import com.dsl.ocrdemo.ocr.views.CameraBaseView;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.ICameraProxyForRecord;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.PreviewDataCallback;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.PreviewSurfaceListener;
import com.dsl.ocrdemo.ocr.views.camera1.interfaces.SurfaceCreatedCallback;
import com.dsl.ocrdemo.ocr.views.camera1.recorder.SAbsVideoRecorder;
import com.dsl.ocrdemo.ocr.views.camera1.recorder.SMediaCodecRecorder;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

/**
 * Created by hetong on 2018/7/4.
 */

public class CameraTextureView extends CameraBaseView implements TextureView.SurfaceTextureListener, Camera.PreviewCallback {
    private String TAG = CameraTextureView.class.getSimpleName();

    private Activity mContext;

    private Camera mCamera;

    private int screenHeight;//屏幕的高度

    private int screenWidth;//屏幕的宽度

    private Camera.Size surportMaxSize;

    private byte[] previewBuffer;

    private SurfaceTexture mSurfaceTexture;

    //录制视频
    public int mCameraFacing = Camera.CameraInfo.CAMERA_FACING_BACK;

    private SAbsVideoRecorder mRecorder;

    private PreviewDataCallback mCallback;


    public CameraTextureView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }


    public void init(Activity context) {
        closeCamera();
        mContext = context;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;

        if(mSurfaceTexture!=null){
            initCamera(mSurfaceTexture);
        }else {
            this.setSurfaceTextureListener(this);
        }

        initRecord();
    }

    private void initRecord() {
        ICameraProxyForRecord cameraProxyForRecord = new ICameraProxyForRecord() {

            @Override
            public void addSurfaceDataListener(PreviewSurfaceListener listener, SurfaceCreatedCallback callback) {

            }

            @Override
            public void removeSurfaceDataListener(PreviewSurfaceListener listener) {

            }

            @Override
            public void addPreviewDataCallback(PreviewDataCallback callback) {
                mCallback = callback;
            }

            @Override
            public void removePreviewDataCallback(PreviewDataCallback callback) {
            }

            @Override
            public int getPreviewWidth() {
                return cameraWidth;
            }

            @Override
            public int getPreviewHeight() {
                return cameraHeight;
            }

            @Override
            public int getVideoRotation() {
                return mCameraFacing == Camera.CameraInfo.CAMERA_FACING_BACK ? 90 : 270;
            }
        };
        mRecorder = new SMediaCodecRecorder(mContext, cameraProxyForRecord);
    }

    public void stopCamera() {
//        try {
//            if (mCamera != null) {
//                mCamera.stopPreview();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public void closeCamera() {
        try {
            if (mCamera != null) {
                mCamera.stopPreview();
                mCamera.release();
                mCamera = null;
                mCallback = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startCamera() {
//        if (mCamera != null) {
//            try {
//                mCamera.startPreview();
//                mCamera.setPreviewCallbackWithBuffer(this);
//                mCamera.setPreviewTexture(mSurfaceTexture);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }catch (RuntimeException e1){}
//            initRecord();
//        } else {
//            init(mContext);
//        }
    }


    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
        DSLLog.i("CameraTextureView","onSurfaceTextureAvailable");
        mSurfaceTexture = surfaceTexture;
        initCamera(surfaceTexture);

    }

    void initCamera(SurfaceTexture surfaceTexture){
        try {
            mSurfaceTexture = surfaceTexture;
            mCamera = Camera.open(mCameraFacing);
            if (mCamera == null) {
                return;
            }
            mCamera.setDisplayOrientation(getCameraAngle());
            // 设置holder主要是用于surfaceView的图片的实时预览，以及获取图片等功能，可以理解为控制camera的操作..
            DSLLog.i("setDisplayOrientation","carema: " + getCameraAngle());
            setCameraParms();
            mCamera.setPreviewTexture(surfaceTexture);

            mCamera.startPreview();

            mCamera.cancelAutoFocus();
            requestLayout();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.d(TAG, "Exception MediaRecorder: " + e.getMessage());
            Toast.makeText(mContext, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    private void setCameraParms() {
        Camera.Parameters cameraParam = mCamera.getParameters();
        List<String> flashModes = cameraParam.getSupportedFlashModes();
        String flashMode = cameraParam.getFlashMode();
        // Check if camera flash exists
        if (flashModes == null) {
            return;
        }
        if (!Camera.Parameters.FLASH_MODE_OFF.equals(flashMode)) {
            // Turn off the flash
            if (flashModes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
                cameraParam.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            }
        }

        surportMaxSize = mCamera.getParameters().getSupportedPreviewSizes().get(0);

        Camera.Size bestPreviewSize = getBestPreviewSize(
                screenHeight, screenWidth, mCamera.getParameters().getSupportedPreviewSizes());

        cameraWidth = bestPreviewSize.width;
        cameraHeight = bestPreviewSize.height;
        DSLLog.i("Camera","cameraWidth: " + cameraWidth + " cameraHeight:" + cameraHeight);

        DSLLog.i("bestPreviewSize","surportMaxSize width: " + surportMaxSize.width + " height：" + surportMaxSize.height);

        List<String> focusModes = cameraParam.getSupportedFocusModes();
        for (String s : focusModes) {
            if (Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO.equals(s)) {
                cameraParam.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                break;
            }
        }
//        // 设置预浏尺寸，注意要在摄像头支持的范围内选择
        cameraParam.setPreviewSize(cameraWidth, cameraHeight);

        cameraParam.setPreviewFormat(ImageFormat.NV21);

        this.previewBuffer = new byte[(int) (cameraWidth * cameraHeight * 3f)];
        mCamera.addCallbackBuffer(previewBuffer);
        mCamera.setPreviewCallbackWithBuffer(this);
        try {
            mCamera.setParameters(cameraParam);
        } catch (RuntimeException e) {
            if (e != null && "setParameters failed".equals(e.getMessage())) {
                cameraWidth = surportMaxSize.width;
                cameraHeight = surportMaxSize.height;
                // 设置预浏尺寸，注意要在摄像头支持的范围内选择
                this.previewBuffer = new byte[(int) (cameraWidth * cameraHeight * 3f)];
                cameraParam.setPreviewSize(cameraWidth, cameraHeight);
                mCamera.setParameters(cameraParam);
            }
        }
    }



    /**
     * 通过对比得到与宽高比最接近的尺寸（如果有相同尺寸，优先选择）
     *
     * @param surfaceWidth  需要被进行对比的原宽
     * @param surfaceHeight 需要被进行对比的原高
     * @param sizes         需要对比的预览尺寸列表
     * @return 得到与原宽高比例最接近的尺寸
     */
    protected Camera.Size getBestPreviewSize(int surfaceWidth, int surfaceHeight,
                                              List<Camera.Size> sizes) {

        Camera.Size selectSize = null;
        // 得到与传入的宽高比最接近的size
        float reqRatio = ((float) surfaceWidth) / surfaceHeight;
        float curRatio, deltaRatio;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            curRatio = ((float) sizes.get(i).width) / sizes.get(i).height;
            deltaRatio = Math.abs(reqRatio - curRatio);
            if (deltaRatio == 0f && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        //先查找preview中是否存在与surfaceview相同宽高的尺寸
        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            if ((sizes.get(i).width == surfaceWidth) && (sizes.get(i).height == surfaceHeight) && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        surfaceWidth = 1920;
        surfaceHeight = 1080;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            if ((sizes.get(i).width == surfaceWidth) && (sizes.get(i).height == surfaceHeight) && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        // 得到与传入的宽高比最接近的size
        reqRatio = ((float) surfaceWidth) / surfaceHeight;
        float deltaRatioMin = Float.MAX_VALUE;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            curRatio = ((float) sizes.get(i).width) / sizes.get(i).height;
            deltaRatio = Math.abs(reqRatio - curRatio);
            if (deltaRatio < deltaRatioMin && sizes.get(i).width < 2000) {
                deltaRatioMin = deltaRatio;
                selectSize = sizes.get(i);
            }
        }
        return selectSize;
    }


    public void changeFlashLight(boolean openOrClose) {
        try {
            Camera.Parameters myParam = mCamera.getParameters();
            List<String> flashModes = myParam.getSupportedFlashModes();
            // Check if camera flash exists
            if (flashModes == null) {
                return;
            }
            if (openOrClose) {
                myParam.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
            } else {
                myParam.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            }
            mCamera.setParameters(myParam);
        } catch (RuntimeException e) {
        }
    }

    /**
     * 获取照相机旋转角度
     */
    public int getCameraAngle() {
        int rotateAngle = 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);
        int rotation = ((Activity) mContext).getWindowManager().getDefaultDisplay().getRotation();
        DSLLog.i("Rotation","ActivityRotation: " + rotation);
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            rotateAngle = (info.orientation + degrees) % 360;
            rotateAngle = (360 - rotateAngle) % 360; // compensate the mirror
        } else { // back-facing
            rotateAngle = (info.orientation - degrees + 360) % 360;
        }
        return rotateAngle;
    }

    @Override
    public void takePhoto() {
        if (mCamera != null) {
            mCamera.takePicture(null, null, jpegCallBack);
        }
    }

    private Camera.PictureCallback jpegCallBack = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(final byte[] data, Camera camera) {
            BufferedOutputStream bos = null;
            try {
                bos = new BufferedOutputStream(new FileOutputStream(OcrSDKManager.za_hk_takephoto));
                bos.write(data);
                // 刷出缓冲输出流，该步很关键，要是不执行flush()方法，那么文件的内容是空的。
                bos.flush();
                Log.e("Camera>>>>>>>>>", "拍照图片写入成功");
                camera.stopPreview();
                camera.startPreview();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };



    long time=System.currentTimeMillis();

    int index=0;

    @Override
    public void onPreviewFrame(final byte[] bytes,final Camera camera) {
        if (null == bytes) {
            camera.addCallbackBuffer(this.previewBuffer);
        } else {
            camera.addCallbackBuffer(bytes);
        }

        if(!OcrNative.getInstance().isPushBuffer){//是否发动图片帧
            return;
        }

        try {
            if(null != bytes) {
                FileOutputStream outStream = null;

                //传递视频帧进入算法
                if(OcrNative.getInstance().getOcrThreadHandler()!=null) {
                    Message message = OcrNative.getInstance().getOcrThreadHandler().obtainMessage();
                    message.what = 9;
                    Bundle data = message.getData();
                    data.putFloat("lens_position", 0f);
                    data.putInt("idx", index);
                    data.putInt("width", cameraWidth);
                    data.putInt("height", cameraHeight);
                    data.putByteArray("previewBuffer", bytes);
                    message.setData(data);
                    OcrNative.getInstance().getOcrThreadHandler().sendMessage(message);
                    Log.e("onPreviewFrame>>>>>>>>>", "视频帧传入算法 width:" + cameraWidth +" height:" + cameraHeight);

                    if (System.currentTimeMillis() - time >= 60) {
                        if(OcrNative.getInstance().startIndex){
                            index++;
                        }
                        time = System.currentTimeMillis();
                        //采集视频帧合成视频
                        if (mCallback != null) {
                            long timeUs = System.nanoTime() / 1000;
                            mCallback.onPreviewData(bytes, previewBuffer, timeUs);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public SAbsVideoRecorder requestRecordListener() {
        return mRecorder;
    }
}

