package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

import android.content.Context;

public interface IReporter {
    void reportError(Throwable t);

    void reportEvent_SOURCE_VIDEO_ENCODE_FPS(Context context, int duration);

    void reportEvent_SOURCE_VIDEO_ENCODE_FPS_API18(Context context, int duration);
}
