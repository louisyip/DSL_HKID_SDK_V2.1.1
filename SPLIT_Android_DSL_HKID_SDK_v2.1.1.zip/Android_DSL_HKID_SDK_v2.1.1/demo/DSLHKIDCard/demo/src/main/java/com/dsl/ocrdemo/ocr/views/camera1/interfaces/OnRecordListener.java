package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

import com.dsl.ocrdemo.ocr.views.camera1.bean.VideoInfo;

public interface OnRecordListener {
    void onRecordSuccess(VideoInfo videoInfo);

    void onRecordStart();

    void onRecordFail(Throwable t);

    void onRecordStop();

    void onRecordPause();

    void onRecordResume();
}
