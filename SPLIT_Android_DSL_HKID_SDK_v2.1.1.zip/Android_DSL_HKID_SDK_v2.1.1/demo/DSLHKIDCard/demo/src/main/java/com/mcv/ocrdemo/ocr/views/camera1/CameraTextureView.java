package com.mcv.ocrdemo.ocr.views.camera1;

import android.app.Activity;
import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Bundle;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;

import com.dsl.mcv.manager.McvNative;
import com.dsl.ocr.util.DSLLog;

import java.util.List;

/**
 * Created by hetong on 2018/7/4.
 */

public class CameraTextureView extends TextureView implements TextureView.SurfaceTextureListener, Camera.PreviewCallback {
    private String TAG = CameraTextureView.class.getSimpleName();

    private Activity mContext;

    private Camera mCamera;

    private int screenHeight;//屏幕的高度

    private int screenWidth;//屏幕的宽度

    public int cameraWidth;//摄像头预览宽

    public int cameraHeight;//摄像头预览高

    private byte[] previewBuffer;

    private SurfaceTexture mSurfaceTexture;

    public int mCameraFacing = Camera.CameraInfo.CAMERA_FACING_BACK;

    int step = 1;


    public CameraTextureView(Context context) {
        super(context);
    }

    public CameraTextureView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CameraTextureView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);
        if(cameraWidth == 0 || cameraHeight == 0){
            setMeasuredDimension(width,height);
        }else{
            if (width > height * cameraHeight / cameraWidth) {
                setMeasuredDimension(width, width * cameraWidth / cameraHeight);
            } else {
                setMeasuredDimension(height * cameraHeight / cameraWidth, height);
            }
        }
    }


    public void init(Activity context) {
        closeCamera();
        mContext = context;
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels;

        if (mSurfaceTexture != null) {
            initCamera(mSurfaceTexture);
        } else {
            this.setSurfaceTextureListener(this);
        }
    }

    public void stopCamera() {
//        try {
//            if (mCamera != null) {
//                mCamera.stopPreview();
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public void closeCamera() {
        try {
            if (mCamera != null) {
//                mCamera.setPreviewCallbackWithBuffer(null);
                mCamera.stopPreview();
                mCamera.release();
                mCamera = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void startCamera() {
//        if (mCamera != null) {
//            try {
//                mCamera.startPreview();
//                mCamera.setPreviewCallbackWithBuffer(this);
//                mCamera.setPreviewTexture(mSurfaceTexture);
//            } catch (IOException e) {
//                e.printStackTrace();
//            }catch (RuntimeException e1){}
//            initRecord();
//        } else {
//            init(mContext);
//        }
    }


    @Override
    public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
        DSLLog.i("CameraTextureView", "onSurfaceTextureAvailable");
        mSurfaceTexture = surfaceTexture;
        initCamera(surfaceTexture);

    }

    void initCamera(SurfaceTexture surfaceTexture) {
        try {
            mSurfaceTexture = surfaceTexture;
            mCamera = Camera.open(mCameraFacing);
            if (mCamera == null) {
                return;
            }
            mCamera.setDisplayOrientation(getCameraAngle());
            // 设置holder主要是用于surfaceView的图片的实时预览，以及获取图片等功能，可以理解为控制camera的操作..

            setCameraParms();
            mCamera.setPreviewTexture(surfaceTexture);

            mCamera.startPreview();

            mCamera.cancelAutoFocus();
            requestLayout();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.d(TAG, "Exception MediaRecorder: " + e.getMessage());
        }
    }

    @Override
    public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

    }

    @Override
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
        if (mCamera != null) {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
        return false;
    }

    @Override
    public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

    }

    private void setCameraParms() {
        Camera.Parameters myParam = mCamera.getParameters();
        List<String> flashModes = myParam.getSupportedFlashModes();
        String flashMode = myParam.getFlashMode();
        // Check if camera flash exists
        if (flashModes == null) {
            return;
        }
        if (!Camera.Parameters.FLASH_MODE_OFF.equals(flashMode)) {
            // Turn off the flash
            if (flashModes.contains(Camera.Parameters.FLASH_MODE_OFF)) {
                myParam.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            }
        }

        surportMaxSize = mCamera.getParameters().getSupportedPictureSizes().get(0);

        Camera.Size bestPreviewSize = getBestPreviewSize(
                screenHeight, screenWidth, mCamera.getParameters().getSupportedPreviewSizes());
        cameraWidth = bestPreviewSize.width;
        cameraHeight = bestPreviewSize.height;

        DSLLog.i("宽和高",cameraWidth+"==="+cameraHeight);

        List<String> focusModes = myParam.getSupportedFocusModes();
        for (String s : focusModes) {
            if (Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO.equals(s)) {
                myParam.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                break;
            }
        }
//        // 设置预浏尺寸，注意要在摄像头支持的范围内选择
        myParam.setPreviewSize(cameraWidth, cameraHeight);

        myParam.setPreviewFormat(ImageFormat.NV21);
        this.previewBuffer = new byte[(int) (cameraWidth * cameraHeight * 3f)];
        mCamera.addCallbackBuffer(previewBuffer);
        mCamera.setPreviewCallbackWithBuffer(this);
        try {
            mCamera.setParameters(myParam);
        } catch (RuntimeException e) {
            if (e != null && "setParameters failed".equals(e.getMessage())) {
                cameraWidth = surportMaxSize.width;
                cameraHeight = surportMaxSize.height;
                // 设置预浏尺寸，注意要在摄像头支持的范围内选择
                this.previewBuffer = new byte[(int) (cameraWidth * cameraHeight * 3f)];
                myParam.setPreviewSize(cameraWidth, cameraHeight);
                mCamera.setParameters(myParam);
            }
        }
    }

    private Camera.Size surportMaxSize;

    /**
     * 通过对比得到与宽高比最接近的尺寸（如果有相同尺寸，优先选择）
     *
     * @param surfaceWidth  需要被进行对比的原宽
     * @param surfaceHeight 需要被进行对比的原高
     * @param sizes         需要对比的预览尺寸列表
     * @return 得到与原宽高比例最接近的尺寸
     */
    protected Camera.Size getBestPreviewSize(int surfaceWidth, int surfaceHeight,
                                             List<Camera.Size> sizes) {

        Camera.Size selectSize = null;
        // 得到与传入的宽高比最接近的size
        float reqRatio = ((float) surfaceWidth) / surfaceHeight;
        float curRatio, deltaRatio;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            curRatio = ((float) sizes.get(i).width) / sizes.get(i).height;
            deltaRatio = Math.abs(reqRatio - curRatio);
            if (deltaRatio == 0f && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        //先查找preview中是否存在与surfaceview相同宽高的尺寸
        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            if ((sizes.get(i).width == surfaceWidth) && (sizes.get(i).height == surfaceHeight) && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        surfaceWidth = 1920;
        surfaceHeight = 1080;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            if ((sizes.get(i).width == surfaceWidth) && (sizes.get(i).height == surfaceHeight) && sizes.get(i).width < 2000) {
                return sizes.get(i);
            }
        }

        // 得到与传入的宽高比最接近的size
        reqRatio = ((float) surfaceWidth) / surfaceHeight;
        float deltaRatioMin = Float.MAX_VALUE;

        for (int i = 0; i < sizes.size(); i++) { //遍历所有Size
            curRatio = ((float) sizes.get(i).width) / sizes.get(i).height;
            deltaRatio = Math.abs(reqRatio - curRatio);
            if (deltaRatio < deltaRatioMin && sizes.get(i).width < 2000) {
                deltaRatioMin = deltaRatio;
                selectSize = sizes.get(i);
            }
        }
        return selectSize;
    }


    public void changeFlashLight(boolean openOrClose) {
        try {
            Camera.Parameters myParam = mCamera.getParameters();
            List<String> flashModes = myParam.getSupportedFlashModes();
            String flashMode = myParam.getFlashMode();
            // Check if camera flash exists
            if (flashModes == null) {
                return;
            }
            if (openOrClose) {
                myParam.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
            } else {
                myParam.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
            }
            mCamera.setParameters(myParam);
        } catch (RuntimeException e) {
        }
    }

    /**
     * 获取照相机旋转角度
     */
    public int getCameraAngle() {
        int rotateAngle = 90;
        Camera.CameraInfo info = new Camera.CameraInfo();
        Camera.getCameraInfo(0, info);
        int rotation = ((Activity) mContext).getWindowManager().getDefaultDisplay().getRotation();
        int degrees = 0;
        switch (rotation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            rotateAngle = (info.orientation + degrees) % 360;
            rotateAngle = (360 - rotateAngle) % 360; // compensate the mirror
        } else { // back-facing
            rotateAngle = (info.orientation - degrees + 360) % 360;
        }
        return rotateAngle;
    }

    public void setStep(int step) {
        this.step = step;
    }

    public int getStep() {
        return step;
    }

    @Override
    public void onPreviewFrame(final byte[] bytes, final Camera camera) {
        if (null == bytes) {
            camera.addCallbackBuffer(this.previewBuffer);
        } else {
            camera.addCallbackBuffer(bytes);
        }

        if (!McvNative.getInstance().isPushBuffer) {//是否发动图片帧
            return;
        }

        try {
            if (null != bytes) {
                //传递视频帧进入算法
                if (McvNative.getInstance().getOcrThreadHandler() != null) {
                    Message message = McvNative.getInstance().getOcrThreadHandler().obtainMessage();
                    message.what = 9;
                    Bundle data = message.getData();
                    data.putInt("width", cameraWidth);
                    data.putInt("height", cameraHeight);
                    data.putInt("step", step);
                    data.putByteArray("previewBuffer", bytes);
                    message.setData(data);
                    McvNative.getInstance().getOcrThreadHandler().sendMessage(message);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

