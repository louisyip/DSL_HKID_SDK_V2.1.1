package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

public interface PreviewDataCallback {
    /**
     * @param data
     * @param timeUs 单位us(例如:System.nanoTime()/1000)
     */
    void onPreviewData(byte[] data,byte[] previewBuffer, long timeUs);
}
