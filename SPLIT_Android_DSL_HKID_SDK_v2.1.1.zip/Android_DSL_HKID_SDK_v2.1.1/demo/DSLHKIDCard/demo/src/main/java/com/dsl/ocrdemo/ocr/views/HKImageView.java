package com.dsl.ocrdemo.ocr.views;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.widget.ImageView;

import com.dsl.ocr.util.DSLLog;

@SuppressLint("AppCompatCustomView")
public class HKImageView extends ImageView {
        public HKImageView(Context context) {
            super(context);
        }

        public HKImageView(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public HKImageView(Context context, AttributeSet attrs,
                              int defStyle) {
            super(context, attrs, defStyle);
        }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int screenWidth = dm.widthPixels;
        int screenHeight = dm.heightPixels;
        if (screenWidth < screenHeight) {
            setMeasuredDimension((screenWidth*6/7+50), (screenWidth*6/7+50)*278/450);
        } else {
            setMeasuredDimension(screenHeight, screenHeight*278/450);
            // setMeasuredDimension(screenHeight*6/7, screenHeight*6/7*450/278);
        }
    }

    @Override
        protected void onDraw(Canvas canvas) {
            canvas.setDrawFilter(new PaintFlagsDrawFilter(0, Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
            super.onDraw(canvas);
        }
    }
