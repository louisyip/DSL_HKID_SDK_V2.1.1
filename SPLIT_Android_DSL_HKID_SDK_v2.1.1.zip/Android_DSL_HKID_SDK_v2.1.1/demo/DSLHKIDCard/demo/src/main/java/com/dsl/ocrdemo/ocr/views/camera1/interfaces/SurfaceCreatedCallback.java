package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

public interface SurfaceCreatedCallback {
    void setSurfaceCreateCallback(OnSurfaceCreatedCallback createCallback);
}
