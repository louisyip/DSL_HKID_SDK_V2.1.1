package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

public interface ICameraProxyForRecord {
    void addSurfaceDataListener(PreviewSurfaceListener listener, SurfaceCreatedCallback callback);

    void removeSurfaceDataListener(PreviewSurfaceListener listener);

    void addPreviewDataCallback(PreviewDataCallback callback);

    void removePreviewDataCallback(PreviewDataCallback callback);

    /**
     * @return 视频需要旋转的角度
     */
    int getVideoRotation();

    int getPreviewWidth();

    int getPreviewHeight();
}
