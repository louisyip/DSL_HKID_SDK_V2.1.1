package com.mcv.ocrdemo.ocr.views;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.dsl.ocrdemo.R;


public class HelpDialog extends Dialog {

    private Context context;
    private ImageView help_cancel;

    TextView highRiskText,lowHighRiskText,lowRiskText;


    private float low_risk;
    private float high_risk;


    public HelpDialog(Activity context, float low_risk, float high_risk) {
        super(context, R.style.privatedialog);
        this.context = context;

        this.low_risk=low_risk;
        this.high_risk=high_risk;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mcv_helpdialog);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        help_cancel = (ImageView) findViewById(R.id.help_cancel);
        help_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HelpDialog.this.dismiss();
            }
        });

        highRiskText=findViewById(R.id.highRiskText);
        lowHighRiskText=findViewById(R.id.lowHighRiskText);
        lowRiskText=findViewById(R.id.lowRiskText);

        highRiskText.setText(low_risk+"以下（高风险）");
        lowHighRiskText.setText(low_risk+"~"+high_risk+"（中风险）");
        lowRiskText.setText(high_risk+"以上（低风险）");
    }

}
