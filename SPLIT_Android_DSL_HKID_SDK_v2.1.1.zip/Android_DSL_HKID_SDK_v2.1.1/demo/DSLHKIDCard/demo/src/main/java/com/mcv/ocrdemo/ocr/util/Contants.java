package com.mcv.ocrdemo.ocr.util;

/**
 * 常量参数
 */

public class Contants {

    public static String context_id= "";

    public static String vertical_front="vertical_front";
    public static String light_vertical_front="light_vertical_front";
    public static String inclined_front="inclined_front";
    public static String vertical_back="vertical_back";
    public static String vertical_front_crop="vertical_front_crop";
    public static String vertical_back_crop="vertical_back_crop";

    public static String daResult="";

    public static String ocrResult="";



}
