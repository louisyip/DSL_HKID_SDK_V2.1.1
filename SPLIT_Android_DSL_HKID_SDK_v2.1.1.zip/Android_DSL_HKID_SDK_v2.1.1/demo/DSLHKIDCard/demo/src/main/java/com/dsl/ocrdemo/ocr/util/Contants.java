package com.dsl.ocrdemo.ocr.util;

import android.util.DisplayMetrics;

import com.dsl.ocr.util.DSLOcrApplications;

/**
 * 常量参数
 */

public class Contants {

    public final static  int CALLBACKDATA_SUCCESS=10000;//成功

    public final static int CALLBACKDATA_VIDEO_FAIL=10001;//失败

    public final static int CALLBACKDATA_CANCEL=10002;//取消

    public final static int CALLBACKDATA_EXCEED=10003;//超时

    public static long dRecStartTimeStamp;//视频开始录制时间,精确到毫秒；

    public static long dORTHTimeStamp;//检测到正对时间,精确到毫秒；

    public static long dRecStartExposureTimeStamp;//闪广打开时间,精确到毫秒

    public static long dRecEndTimeStamp;//视频结束录制时间,精确到毫秒

    public static int isOldOrNew=1;//1是老的身份证，2是新的身份证识别

    public static boolean isLandscape = false; //true横屏模式，false竖屏模式

    public static boolean useLandscape = false; //是否支持横屏

    public static boolean islost = false; //是否證件丟失

    public static String DIRECTION_TYPE="";//DSLHKIDCardOperation_DIRECTION_RIGHT是证件朝向向右，手机翻转向左，DSLHKIDCardOperation_DIRECTION_LEFT是证件朝向向左，手机翻转向右

    public static int event=0;//如果是100表示Da吐的图片OCR识别失败，中断提示用户重新拍摄
    public static String daResult="";
    public static String ocrResult="";
    public static String faceResult="";
    public static String uploadFaceResult="";
    public static String mcroppedFaceImage="";

    public static String uuId= "";

    public static String version_2003="2003";//2003是香港一代身份证识别接口
    public static String version_2018="2018";//2018香港二代身份证识别接口

    public static long video_time_length=0l;//视频时长

    public static boolean online_collect=false;//是否在线采集

}
