package com.mcv.ocrdemo.ocr.views;


import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import com.dsl.ocrdemo.R;


public class ErrorDialog extends Dialog {

    private Context context;
    TextView alertBtn;
    String type="";

    TextView title,desc,guideText;


    View.OnClickListener onClickListener;

    public ErrorDialog(Context context, String type) {
        super(context, R.style.privatedialog);
        this.context = context;
        this.type=type;
    }

    public void setOnClickListener(View.OnClickListener onClickListener){
            this.onClickListener=onClickListener;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mcv_errordialog);
        getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);

        title=findViewById(R.id.title);
        desc=findViewById(R.id.desc);
        guideText=findViewById(R.id.guideText);
        guideText.setOnClickListener(onClickListener);

        alertBtn=(TextView)findViewById(R.id.alertBtn);
        alertBtn.setTag(type);
        alertBtn.setOnClickListener(onClickListener);

        if("LOST".equals(type)){
            title.setText("证件丢失");
            desc.setText("请保持证件在提示框区域");
        }else if("OVERTIME".equals(type)){
            title.setText("识别超时");
            desc.setText("请勿停留时间过长");
        }else if("INVALID".equals(type)){
            title.setText("证件识别失败");
            desc.setText("服务器请求问题，请重新尝试");
        }

    }
}
