package com.dsl.ocrdemo.ocr.views.camera1.encoder;

import android.media.MediaMuxer;

import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.LinkedBlockingQueue;

import com.dsl.ocrdemo.ocr.views.camera1.recorder.OnRecordFailListener;
import com.dsl.ocrdemo.ocr.views.camera1.utils.RL;
import com.dsl.ocrdemo.ocr.views.camera1.utils.SVideoUtil;
import com.dsl.ocrdemo.ocr.views.camera1.utils.TimeOutThread;

public class VideoMediaEncoderThread extends TimeOutThread implements Thread.UncaughtExceptionHandler {

    protected LinkedBlockingQueue<SaveRequest> mQueue;

    protected VideoEncoderFromBuffer mRecorder;

    protected boolean mStop = false;

    protected int mRecordedFrames;
    protected int mFrameRate;
    protected OnRecordProgressListener mOnRecordProgressListener;
    protected LinkedList<byte[]> mDataObjectPool = new LinkedList<byte[]>();
    protected OnRecordFailListener mOnRecordFailListener;

    protected boolean mIsSuccess;
    protected boolean mInited;

    /**
     * 根据帧的时间戳得出
     */
    private long mDuration;
    private long mFirstFrameTime = -1;

    protected int mWidth;
    protected int mHeight;
    protected byte[] mLastFrameYUV;
    protected long mLastFrameTime;
    private String mSdkEffectKey;

    // Runs in main thread
    public VideoMediaEncoderThread(int width, int height, int bitRate, int frameRate, int iFrameInterval, String path, MediaMuxer mediaMuxer, CountDownLatch countDownLatch) {
        super(countDownLatch);
        mWidth = width;
        mHeight = height;
        setPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        setName("VideoMediaEncoderThread");
        mQueue = new LinkedBlockingQueue<SaveRequest>();
        mFrameRate = frameRate;
        initRecorder(
                width,
                height,
                bitRate,
                frameRate,
                iFrameInterval,
                path,
                mediaMuxer
        );
    }

    protected void initRecorder(int width, int height, int bitRate, int frameRate, int iFrameInterval, String path, MediaMuxer mediaMuxer) {
        if (SVideoUtil.AFTER_LOLLIPOP) {
            mRecorder = new VideoEncoderApi21(
                    width,
                    height,
                    bitRate,
                    frameRate,
                    iFrameInterval,
                    path,
                    mediaMuxer
            );
        } else {
            mRecorder = new VideoEncoderFromBuffer(
                    width,
                    height,
                    bitRate,
                    frameRate,
                    iFrameInterval,
                    mediaMuxer
            );
        }
    }

    @Override
    public void run() {
        if (mRecorder == null) {
            mCountDonwLatch.countDown();
            return;
        }
        if (!mInited) {
            Thread.currentThread().setUncaughtExceptionHandler(this);
            mInited = true;
            RL.i("+initInThread");
            mRecorder.initInThread();
            RL.i("-initInThread");
        }
        while (true) {
            SaveRequest r = null;
            try {
                RL.i("+mQueue.take");
                r = mQueue.take();
                RL.i("-mQueue.take");
                if (r.data == null) {
                    break;
                }
            } catch (InterruptedException e) {
                RL.e(e);
                continue;
            }
            RL.i("+encodeFrame");
            long s = System.currentTimeMillis();
            mRecorder.encodeFrame(r.data, r.fpsTimeUs);
            long e = System.currentTimeMillis();
            RL.i("-encodeFrame");
            synchronized (mDataObjectPool) {
                mDataObjectPool.add(r.data);
            }
            mRecordedFrames++;
            RL.i("mRecorder.encodeFrame:" + (e - s) + "ms");
            if (mFirstFrameTime < 0) {
                mFirstFrameTime = r.fpsTimeUs / 1000;
            }

            mDuration = r.fpsTimeUs / 1000 - mFirstFrameTime;
            //计算录制时间
            if (mOnRecordProgressListener != null) {
                int recordedDuration = (int) ((1000f / mFrameRate) * mRecordedFrames);
                mOnRecordProgressListener.onRecording(recordedDuration);
            }
        }
        RL.i("总帧数:" + mRecordedFrames);

        mDataObjectPool.clear();
        mQueue.clear();
        mRecorder.close();
        mIsSuccess = true;
        mCountDonwLatch.countDown();
    }

    // Runs in main thread
    public void addImageData(final byte[] data,byte[] previewBuffer, long time) {
        if (mStop || mQueue == null) {
            return;
        }
//        L.it(TAG, " addImageData data.length = " + data.length);
        if (mDataObjectPool.size() > 0) {
            synchronized (mDataObjectPool) {
                previewBuffer = mDataObjectPool.pop();
            }
        }
        System.arraycopy(data, 0, previewBuffer, 0, data.length);
        SaveRequest r = new SaveRequest();
        mLastFrameYUV = previewBuffer;
        mLastFrameTime = time;
        r.data = previewBuffer;
        r.fpsTimeUs = time;
        if (mQueue.size() < 100) {
            mQueue.add(r);
        }
    }

    /**
     * 根据帧的时间戳算出的，可能不准
     *
     * @return
     */
    public long getDuration() {
        return mDuration;
    }

    public boolean isSuccess() {
        return mIsSuccess;
    }

    public void finish() {
        SaveRequest r = new SaveRequest();
        r.data = null;
        r.fpsTimeUs = 0;
        mQueue.add(r);
        mStop = true;

        mLastFrameYUV = null;
        mLastFrameTime = 0;
    }

    @Deprecated
    public void forceFinish() {
        RL.i("forceFinish视频线程，还剩:" + mQueue.size() + "帧未写完");
        SaveRequest r = new SaveRequest();
        r.data = null;
        r.fpsTimeUs = 0;
        mQueue.clear();
        mQueue.add(r);
        mStop = true;
    }

    public int getRecordedFrames() {
        return mRecordedFrames + 1;//测了几个都多一帧，可能是结尾写的空帧？
    }

    public void setOnRecordProgressListener(OnRecordProgressListener onRecordProgressListener) {
        this.mOnRecordProgressListener = onRecordProgressListener;
    }

    public void setOnRecordFailListener(OnRecordFailListener onRecordFailListener) {
        this.mOnRecordFailListener = onRecordFailListener;
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        mCountDonwLatch.countDown();
        throwRecordError(ex);
    }

    public int getQueueSize() {
        return mQueue == null ? 0 : mQueue.size();
    }

    static class SaveRequest {
        long fpsTimeUs;
        byte[] data;
    }

    public void throwRecordError(Throwable e) {
        if (mOnRecordFailListener != null) {
            mOnRecordFailListener.onVideoRecordFail(e, true);
        }
        RL.e(e);
        if (mRecorder != null) {
            mRecorder.close();
        }
    }
}
