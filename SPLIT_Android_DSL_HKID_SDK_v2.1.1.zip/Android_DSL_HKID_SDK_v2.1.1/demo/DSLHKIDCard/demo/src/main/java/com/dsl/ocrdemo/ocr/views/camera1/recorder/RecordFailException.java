package com.dsl.ocrdemo.ocr.views.camera1.recorder;

public class RecordFailException extends RuntimeException {
    public RecordFailException(String msg) {
        super(msg);
    }

    public RecordFailException(Exception e) {
        super(e);
    }
}
