package com.mcv.ocrdemo.ocr.manager;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;

import com.dsl.mcv.manager.McvNative;
import com.dsl.ocr.util.DSLLog;
import com.dsl.ocr.util.DSLOcrApplications;
import com.mcv.ocrdemo.ocr.DSLMCVIDActivity;

/**
 * ocr 管理器
 *
 */
public class McvSDKManager {

    public static String basePath=DSLOcrApplications.context().getExternalCacheDir()+"/ocrFile/";

    private long mLastClickTime = 0;
    public static final long TIME_INTERVAL = 1000L;

    /**
     * 是否为调试模式
     */
    private boolean mIsDebugModle;

    @SuppressLint("StaticFieldLeak")
    private static final McvSDKManager ourInstance = new McvSDKManager();


    private McvNative mMcvNative;

    public static synchronized McvSDKManager getInstance() {
        return ourInstance;
    }

    private McvSDKManager() {
        mMcvNative = McvNative.getInstance();
    }

    /**
     * 是否开启调试模式
     *
     * @param isDebug
     */
    public void enableDebug(boolean isDebug) {
        mIsDebugModle = isDebug;
        DSLLog.setDebug(mIsDebugModle);
    }


    /**
     * 手持离线版本2018
     */
    public void startMcvIDCard(Activity context) {
        long nowTime = System.currentTimeMillis();
        if (nowTime - mLastClickTime > TIME_INTERVAL) {
            mLastClickTime = nowTime;
            mMcvNative.initModel(context);
            Intent intent = new Intent(context, DSLMCVIDActivity.class);
            context.startActivity(intent);
        }
    }

    public void init(String fileBasePath,String modeBasePath){
        basePath=fileBasePath;
        mMcvNative.initModelBasePath(modeBasePath);
    }

}
