package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

public interface IVideoPathGenerator {
    String generate();
}
