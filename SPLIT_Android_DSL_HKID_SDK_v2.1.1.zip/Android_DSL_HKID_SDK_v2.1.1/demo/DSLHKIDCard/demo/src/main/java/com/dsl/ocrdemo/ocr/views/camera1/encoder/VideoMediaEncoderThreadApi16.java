package com.dsl.ocrdemo.ocr.views.camera1.encoder;

import android.media.MediaMuxer;

import java.util.concurrent.CountDownLatch;

public class VideoMediaEncoderThreadApi16 extends VideoMediaEncoderThread {
    public VideoMediaEncoderThreadApi16(int width, int height, int bitRate, int frameRate, int iFrameInterval, String path, MediaMuxer mediaMuxer, CountDownLatch countDownLatch) {
        super(width, height, bitRate, frameRate, iFrameInterval, path,mediaMuxer, countDownLatch);
    }

    @Override
    protected void initRecorder(int width, int height, int bitRate, int frameRate, int iFrameInterval,String path,MediaMuxer mediaMuxer) {
        mRecorder = new VideoEncoderApi16(
                width,
                height,
                bitRate,
                frameRate,
                iFrameInterval,
                path
        );
    }
}
