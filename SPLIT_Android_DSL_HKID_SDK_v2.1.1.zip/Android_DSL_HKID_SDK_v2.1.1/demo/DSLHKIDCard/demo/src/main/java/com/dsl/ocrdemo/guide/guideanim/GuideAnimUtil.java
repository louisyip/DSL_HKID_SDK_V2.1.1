package com.dsl.ocrdemo.guide.guideanim;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;

import com.dsl.ocrdemo.R;
import com.dsl.ocrdemo.ocr.views.Rotate3dAnimation;

public class GuideAnimUtil {

    public static void playAlphaAnim(final Handler mHandler, final View circleView,final View redView){
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);
        alphaAnimation.setDuration(500);
        alphaAnimation.setRepeatCount(1);
        alphaAnimation.setRepeatMode(Animation.RESTART);
        circleView.setAnimation(alphaAnimation);
        alphaAnimation.start();
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                circleView.clearAnimation();
                animation.cancel();
                if(redView!=null) {
                    redView.clearAnimation();
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            redView.setVisibility(View.VISIBLE);
                            playAlphaAnim(mHandler,redView,redView);
                        }
                    }, 500);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }


    public static   void step2Anim(Context ctx,final Handler mHandler,final View view, final View qingxieCardView,final View qingxieLvView){
        Animation myAnim = AnimationUtils.loadAnimation(ctx, R.anim.slide_in_left);
        myAnim.setFillAfter(true);//android动画结束后停在结束位置
        view.startAnimation(myAnim);
        myAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.clearAnimation();
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        qingxieCardView.setVisibility(View.VISIBLE);
                        qingxieLvView.setVisibility(View.VISIBLE);
                        alphaAnim(mHandler,qingxieLvView,null,null,null,2,null);
                    }
                }, 500);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    private static void alphaAnim(final Handler mHandler,final View view,final View parent,final View vlineView,final View directionImgView,final int step,final String from){
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.1f, 1.0f);
        alphaAnimation.setDuration(500);
        alphaAnimation.setRepeatCount(1);
        view.setAnimation(alphaAnimation);
        alphaAnimation.start();
        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.clearAnimation();
                animation.cancel();
                if(vlineView!=null && directionImgView!=null && from!=null) {
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            switch (step) {
                                case 3:
                                    vlineView.setVisibility(View.VISIBLE);
                                    directionImgView.setVisibility(View.VISIBLE);
                                    if(from.equals("NEW_HK_CARD")){
                                        rotationAnim(parent, 0, 10, true, 1);
                                    }else{
                                        rotationAnim(parent, 0, 10, false, 3);
                                    }
                                    break;
                                case 4:
                                    vlineView.setVisibility(View.VISIBLE);
                                    directionImgView.setVisibility(View.VISIBLE);
                                    if(from.equals("NEW_HK_CARD")){
                                        rotationAnim(parent, 0, -10, true, 2);
                                    }else{
                                        rotationAnim(parent, 0, -10, false, 4);
                                    }
                                    break;
                            }
                        }
                    }, 500);
                }

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    public static void FlipAnimatorXViewShow(final View view, final long time) {

        ObjectAnimator animator1 = ObjectAnimator.ofFloat(view, "rotationX", 0, 30);

//        final ObjectAnimator animator2 = ObjectAnimator.ofFloat(newView, "rotationX", -90, 0);
//        animator2.setInterpolator(new OvershootInterpolator(2.0f));

//        animator1.addListener(new Animator.AnimatorListener() {
//            @Override
//            public void onAnimationStart(Animator animation) {
//
//            }
//
//            @Override
//            public void onAnimationEnd(Animator animation) {
//                oldView.setVisibility(View.GONE);
//                animator2.setDuration(time).start();
//                newView.setVisibility(View.VISIBLE);
//            }
//
//            @Override
//            public void onAnimationCancel(Animator animation) {
//
//            }
//
//            @Override
//            public void onAnimationRepeat(Animator animation) {
//
//            }
//        });
        animator1.setDuration(time).start();
    }

    private static void rotationAnim(final View rectangleView,float end,float start, boolean isVertical,int type) {
        // 计算中心点
        float centerX = rectangleView.getWidth();
        float centerY = rectangleView.getHeight()/2;
        switch (type){
            case  1:
                centerX=rectangleView.getWidth()/2;
                centerY = rectangleView.getHeight()/2;
                break;
            case 2:
                centerX=rectangleView.getWidth();
                centerY = rectangleView.getHeight()/2;
                break;
            case 3:
                centerX=rectangleView.getWidth()*3/4-50;
                centerY = rectangleView.getHeight();
                break;
            case 4:
                centerX=rectangleView.getWidth()*3/4-50;
                centerY = 0;
                break;

        }

        Log.e(start+">>>>>>>>>>"+end,centerX+">>>>>"+centerY);

        // Create a new 3D rotation with the supplied parameter
        // The animation listener is used to trigger the next animation
        //final Rotate3dAnimation rotation =new Rotate3dAnimation(start, end, centerX, centerY, 310.0f, true);
        //Z轴的缩放为0
        Rotate3dAnimation rotation =new Rotate3dAnimation(start, end, centerX, centerY, 0f, isVertical);
        rotation.setDuration(2500);
        rotation.setFillAfter(true);
        //匀速旋转
        rotation.setInterpolator(new LinearInterpolator());
        rotation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        rectangleView.startAnimation(rotation);
    }

    public static   void step3Anim(Context ctx,final Handler mHandler,final View view, final View parent,final View lvView,final View vlineView,final View directionImgView,final int step,final String from){
        Animation myAnim = AnimationUtils.loadAnimation(ctx, R.anim.slide_in_left);
        myAnim.setFillAfter(true);//android动画结束后停在结束位置
        view.startAnimation(myAnim);
        myAnim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.clearAnimation();
                mHandler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        lvView.setVisibility(View.VISIBLE);
                        alphaAnim(mHandler,lvView,parent,vlineView,directionImgView,step,from);
                    }
                }, 500);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

    public static   void step4Anim(Context ctx,final Handler mHandler,final View view, final View parent,final View lvView,final View vlineView,final View directionImgView,final int step,final String from){
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                lvView.setVisibility(View.VISIBLE);
                alphaAnim(mHandler,lvView,parent,vlineView,directionImgView,step,from);
            }
        }, 500);
    }
}
