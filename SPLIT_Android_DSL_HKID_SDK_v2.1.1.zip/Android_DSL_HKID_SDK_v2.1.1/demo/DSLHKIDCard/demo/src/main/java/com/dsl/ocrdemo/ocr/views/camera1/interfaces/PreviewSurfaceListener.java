package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

public interface PreviewSurfaceListener {
    void onFrameAvaibleSoon();
}
