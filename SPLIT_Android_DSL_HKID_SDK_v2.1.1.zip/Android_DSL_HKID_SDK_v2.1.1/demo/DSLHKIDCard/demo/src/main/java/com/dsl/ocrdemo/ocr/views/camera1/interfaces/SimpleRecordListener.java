package com.dsl.ocrdemo.ocr.views.camera1.interfaces;

import com.dsl.ocrdemo.ocr.views.camera1.bean.VideoInfo;

public class SimpleRecordListener implements OnRecordListener {
    @Override
    public void onRecordSuccess(VideoInfo videoInfo) {

    }

    @Override
    public void onRecordStart() {

    }

    @Override
    public void onRecordFail(Throwable t) {

    }

    @Override
    public void onRecordStop() {

    }

    @Override
    public void onRecordPause() {

    }

    @Override
    public void onRecordResume() {

    }
}
