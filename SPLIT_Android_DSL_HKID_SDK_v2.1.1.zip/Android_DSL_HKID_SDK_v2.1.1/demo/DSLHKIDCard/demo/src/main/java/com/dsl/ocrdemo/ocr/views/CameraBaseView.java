package com.dsl.ocrdemo.ocr.views;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.TextureView;

import com.dsl.ocr.util.DSLLog;
import com.dsl.ocrdemo.ocr.views.camera1.recorder.SAbsVideoRecorder;

public abstract class CameraBaseView extends TextureView {

    public int cameraHeight;//对应竖屏的宽度，横屏的高度

    public int cameraWidth;//对应竖屏的高度，横屏的宽度

    private Context context;

    public CameraBaseView(Context context) {
        super(context);
        this.context = context;
    }

    public CameraBaseView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
    }

    public CameraBaseView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int width = MeasureSpec.getSize(widthMeasureSpec);
        int height = MeasureSpec.getSize(heightMeasureSpec);

        int rotation = ((Activity)getContext()).getWindowManager().getDefaultDisplay().getRotation();

        DSLLog.i("setDisplayOrientation","getRotation: " + rotation);
        DSLLog.i("onMeasure","width: " + width + " height:" + height);

        if(cameraWidth == 0 || cameraHeight == 0){
            setMeasuredDimension(width,height);
        }else{
            if(rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) {
                if (width > height * cameraHeight / cameraWidth) {
                    setMeasuredDimension(width, width * cameraWidth / cameraHeight);
                } else {
                    setMeasuredDimension(height * cameraHeight / cameraWidth, height);
                }
            } else if(rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) {
                if (height > width * cameraWidth / cameraHeight) {
                    // setMeasuredDimension(width * cameraWidth / cameraHeight, width); // 按短边宽度适配
                    setMeasuredDimension(height * cameraWidth / cameraHeight, height); //按长边高度适配
                } else {
                    // setMeasuredDimension(1920, 1080); // 按长边宽度适配
                    setMeasuredDimension(width, width * cameraHeight / cameraWidth); // 按长边宽度适配
                    // setMeasuredDimension(height * cameraWidth / cameraHeight, height); // 按短边高度适配
                }
            }
        }
    }

    public abstract void init(Activity activity);

    public abstract void startCamera();

    public abstract void stopCamera();

    public abstract void closeCamera();

    public abstract void takePhoto();

    public abstract void changeFlashLight(boolean openOrClose);

    public abstract SAbsVideoRecorder requestRecordListener();


}
